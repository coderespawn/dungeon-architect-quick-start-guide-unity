﻿using UnityEngine;
using System.Collections;
using DungeonArchitect;

public class DungeonRebuilder : MonoBehaviour {
    public Dungeon dungeon;

    void Awake()
    {
        RebuildDungeon();
    }

	// Update is called once per frame
	void Update () {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            RebuildDungeon();
        }
	}

    void RebuildDungeon()
    {
        if (dungeon != null)
        {
            dungeon.Config.Seed = (uint)(Random.value * int.MaxValue);
            dungeon.RequestRebuild();
        }
    }
}
