﻿using UnityEngine;
using System.Collections;

public class IsaacDemoCam : MonoBehaviour {

    public float movementSensitivity = 1;
    public float zoomSensitivity = 1;

    float targetSize;

    void Awake()
    {
        var cam = Camera.main;
        targetSize = cam.orthographicSize;
    }

    void Update()
    {
        // Handle movement
        var cam = Camera.main;
        var moveX = Input.GetAxis("Horizontal");
        var moveY = Input.GetAxis("Vertical");

        var dx = moveX * movementSensitivity * cam.orthographicSize;
        var dy = moveY * movementSensitivity * cam.orthographicSize;
        transform.position = transform.position + new Vector3(dx, dy, 0);

        // Handle zoom
        var size = targetSize;
        var wheel = Input.GetAxis("Mouse ScrollWheel");
        if (wheel != 0)
        {
            wheel = 0.1f * Mathf.Sign(wheel);
            var multiplier = 1 + (wheel);
            size *= multiplier;
            size = Mathf.Max(10, size);
            targetSize = size;
        }


        var currentSize = cam.orthographicSize;
        cam.orthographicSize = currentSize + (targetSize - currentSize) * zoomSensitivity;

    }
}
